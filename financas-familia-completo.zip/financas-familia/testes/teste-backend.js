// Teste do backend com uma planilha simulada em memória.
const assert = require('assert');
const { criarAmbiente } = require('./ambiente');

let op = 0; const opId = () => 'op-teste-' + (++op);
let nid = 0; const novoId = () => 'aaaaaaaa-bbbb-4ccc-8ddd-' + String(++nid).padStart(12, '0');
const ok = r => { if (!r.ok) throw new Error('Esperava ok: ' + JSON.stringify(r.erro)); return r.data; };
const falha = (r, cod) => { assert.strictEqual(r.ok, false, 'esperava falha ' + cod); if (cod) assert.strictEqual(r.erro.codigo, cod, JSON.stringify(r.erro)); };
let n = 0; const teste = (nome, fn) => { fn(); n++; console.log('✓', nome); };

const A = criarAmbiente();
A.ctx.instalar();

teste('instalar cria as 17 abas na ordem e remove a aba vazia', () => {
  const nomes = A.sheets.map(s => s.nome);
  assert.deepStrictEqual(nomes, ['Usuários', 'Famílias', 'Receitas', 'Despesas', 'Contas a pagar', 'Contas a receber', 'Cartões', 'Compras no cartão', 'Faturas', 'Contas bancárias', 'Transferências', 'Orçamentos', 'Metas financeiras', 'Dívidas', 'Categorias', 'Histórico de alterações', 'Configurações']);
});

teste('iniciar sem família pede configuração', () => {
  const r = ok(A.chamar('iniciar'));
  assert.strictEqual(r.estado, 'configurar'); assert.strictEqual(r.podeCriar, true);
});

teste('não-dono não cria família', () => {
  A.como('intruso@gmail.com');
  const r = ok(A.chamar('iniciar')); assert.strictEqual(r.estado, 'negado');
  A.como('dono@gmail.com');
});

teste('mutação sem opId é recusada', () => falha(A.chamar('criarFamilia', { nomeFamilia: 'X', nomeUsuario: 'Y' }), 'OP_ID'));

let pac;
teste('criar família + conta inicial', () => {
  pac = ok(A.chamar('criarFamilia', { opId: opId(), nomeFamilia: 'Família Aguiar', nomeUsuario: 'Danielle', conta: { nome: 'Nubank', tipo: 'digital', saldo_inicial: '1.000,00', data_saldo_inicial: '2026-09-01' } }));
  assert.strictEqual(pac.estado, 'pronto'); assert.strictEqual(pac.usuario.perfil, 'admin');
  assert.strictEqual(pac.contas.length, 1); assert.strictEqual(pac.contas[0].saldo_inicial, '1000.00');
  assert.ok(pac.categorias.length > 50);
  falha(A.chamar('criarFamilia', { opId: opId(), nomeFamilia: 'Outra', nomeUsuario: 'X' }), 'JA_EXISTE');
});

const contaId = () => pac.contas[0].id;

teste('receita: criar, repetir (sem duplicar), editar, conflito', () => {
  const id = novoId();
  const reg = { id, descricao: 'Salário', valor: '3.500,50', categoria: 'Salário', responsavel: 'Danielle', data: '2026-09-05', status: 'recebida', conta_id: contaId() };
  const o = opId();
  const r1 = ok(A.chamar('salvar', { opId: o, entidade: 'receitas', modo: 'criar', registro: reg }));
  assert.strictEqual(r1.registro.valor, '3500.50');
  ok(A.chamar('salvar', { opId: o, entidade: 'receitas', modo: 'criar', registro: reg })); // mesma operação
  const r3 = ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: reg })); // nova tentativa, mesmo id
  assert.strictEqual(r3.repetido, true);
  assert.strictEqual(ok(A.chamar('listar', { entidade: 'receitas' })).length, 1);
  const r4 = ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'editar', registro: { ...reg, valor: 3600, versao: '1' } }));
  assert.strictEqual(r4.registro.versao, '2'); assert.strictEqual(r4.registro.valor, '3600.00');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'editar', registro: { ...reg, valor: 1, versao: '1' } }), 'CONFLITO');
});

teste('validações: valor, data, texto, conta de outra família', () => {
  const base = { id: novoId(), descricao: 'X', valor: '10', categoria: 'Outros', responsavel: 'Danielle', data: '2026-09-10' };
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, valor: '0' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, valor: 'abc' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, data: '2026-02-30' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, descricao: '' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, conta_id: 'nao-existe' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { ...base, id: 'curto' } }), 'VALIDACAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'faturas', modo: 'criar', registro: base }), 'ACAO_INVALIDA');
});

let despId;
teste('despesas: paga, pendente, vencida; data_pagamento automática', () => {
  despId = novoId();
  const r = ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id: despId, descricao: 'Mercado', valor: '450,25', categoria: 'Alimentação', subcategoria: 'Supermercado', responsavel: 'Danielle', data_compra: '2026-09-08', status: 'paga', conta_id: contaId() } }));
  assert.strictEqual(r.registro.data_pagamento, '2026-09-08');
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id: novoId(), descricao: 'Energia', valor: '200', categoria: 'Moradia', subcategoria: 'Energia elétrica', responsavel: 'Danielle', data_compra: '2026-09-01', data_vencimento: '2026-09-15', status: 'pendente', data_pagamento: '2026-09-15' } }));
  const l = ok(A.chamar('listar', { entidade: 'despesas' }));
  assert.strictEqual(l.find(x => x.descricao === 'Energia').data_pagamento, '');
});

teste('dashboard de setembro: fórmulas', () => {
  const d = ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  const c = d.cards;
  assert.strictEqual(c.receitas.total, 360000);
  assert.strictEqual(c.despesas.total, 45025 + 20000);
  assert.strictEqual(c.despesas.pago, 45025);
  // saldo = 1000 + 3600 − 450,25 (energia pendente não sai do saldo)
  assert.strictEqual(c.saldo.saldo, 100000 + 360000 - 45025);
  assert.strictEqual(c.pendentes.total, 20000);
  assert.strictEqual(c.economia.total, 360000 - 65025);
  assert.strictEqual(c.comprometido.pct, Math.round(65025 * 1000 / 360000) / 10);
  assert.strictEqual(d.serie.length, 6);
  assert.strictEqual(d.porCategoria[0].nome, 'Alimentação');
  assert.ok(d.detalhes.receitas.length === 1 && !('_linha' in d.detalhes.receitas[0]));
});

teste('filtro por pessoa vira movimento líquido (sem saldo inicial)', () => {
  const d = ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30', filtros: { responsavel: 'Danielle' } }));
  assert.strictEqual(d.parcial, true);
  assert.strictEqual(d.cards.saldo.inicial, 0);
});

teste('comprometimento com base em despesas pagas', () => {
  ok(A.chamar('salvarFamilia', { opId: opId(), nome: 'Família Aguiar', base_comprometimento: 'pagas', meta_economia_mensal: '500' }));
  const d = ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  assert.strictEqual(d.cards.comprometido.despesas, 45025);
  assert.ok(d.insights.some(i => i.texto.includes('meta de economia')));
});

let membroId;
teste('convite: compartilha planilha, convidado aceita, perfil membro', () => {
  const r = ok(A.chamar('convidarMembro', { opId: opId(), email: 'Esposo@Gmail.com', nome: 'Carlos', perfil: 'membro' }));
  assert.ok(A.compartilhados.editores.has('esposo@gmail.com'));
  assert.ok(r.urlApp.includes('script.google.com'));
  A.como('esposo@gmail.com');
  assert.strictEqual(ok(A.chamar('iniciar')).estado, 'convite');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: {} }), 'SEM_PERMISSAO');
  const p = ok(A.chamar('aceitarConvite', { opId: opId(), nome: 'Carlos' }));
  assert.strictEqual(p.estado, 'pronto'); assert.strictEqual(p.usuario.perfil, 'membro');
  membroId = p.usuario.id;
});

teste('membro: cria despesa, não administra, respeita editar_todos', () => {
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id: novoId(), descricao: 'Gasolina', valor: '150', categoria: 'Transporte', responsavel: 'Carlos', data_compra: '2026-09-12', status: 'paga' } }));
  falha(A.chamar('convidarMembro', { opId: opId(), email: 'x@y.com' }), 'SEM_PERMISSAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'contas_bancarias', modo: 'criar', registro: { id: novoId(), nome: 'X' } }), 'SEM_PERMISSAO');
  falha(A.chamar('gerarDemo', { opId: opId() }), 'SEM_PERMISSAO');
  // editar_todos=1 por padrão → pode editar despesa da Danielle
  const merc = ok(A.chamar('listar', { entidade: 'despesas' })).find(x => x.id === despId);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'editar', registro: { ...merc, observacoes: 'ok' } }));
  A.como('dono@gmail.com');
  ok(A.chamar('alterarMembro', { opId: opId(), id: membroId, editar_todos: false }));
  A.como('esposo@gmail.com');
  const merc2 = ok(A.chamar('listar', { entidade: 'despesas' })).find(x => x.id === despId);
  falha(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'editar', registro: { ...merc2, observacoes: 'não pode' } }), 'SEM_PERMISSAO');
  falha(A.chamar('excluir', { opId: opId(), entidade: 'despesas', id: despId }), 'SEM_PERMISSAO');
});

teste('visualizador: só lê; revogação corta acesso', () => {
  A.como('dono@gmail.com');
  ok(A.chamar('alterarMembro', { opId: opId(), id: membroId, perfil: 'visualizador' }));
  assert.ok(A.compartilhados.leitores.has('esposo@gmail.com') && !A.compartilhados.editores.has('esposo@gmail.com'));
  A.como('esposo@gmail.com');
  ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  falha(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: {} }), 'SEM_PERMISSAO');
  A.como('dono@gmail.com');
  falha(A.chamar('alterarMembro', { opId: opId(), id: pac.usuario.id, status: 'revogado' }), 'VALIDACAO');
  ok(A.chamar('alterarMembro', { opId: opId(), id: membroId, status: 'revogado' }));
  A.como('esposo@gmail.com');
  assert.strictEqual(ok(A.chamar('iniciar')).estado, 'negado');
  A.como('dono@gmail.com');
});

teste('excluir e desfazer (exclusão lógica + auditoria)', () => {
  ok(A.chamar('excluir', { opId: opId(), entidade: 'despesas', id: despId }));
  assert.ok(!ok(A.chamar('listar', { entidade: 'despesas' })).some(x => x.id === despId));
  ok(A.chamar('restaurar', { opId: opId(), entidade: 'despesas', id: despId }));
  assert.ok(ok(A.chamar('listar', { entidade: 'despesas' })).some(x => x.id === despId));
  const hist = A.ss.getSheetByName('Histórico de alterações');
  const acoes = hist.data.slice(1).map(r => r[4]);
  ['criar', 'editar', 'excluir', 'restaurar', 'convidar', 'aceitar_convite', 'alterar_membro'].forEach(a => assert.ok(acoes.includes(a), 'falta auditoria ' + a));
});

teste('edição altera só a própria linha (resto da planilha intacto)', () => {
  const sh = A.ss.getSheetByName('Receitas');
  const antes = JSON.stringify(sh.data);
  const outraId = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { id: outraId, descricao: 'Venda', valor: '80', categoria: 'Vendas', responsavel: 'Danielle', data: '2026-09-20' } }));
  const snapshot = JSON.stringify(sh.data.slice(0, 2));
  const r = ok(A.chamar('listar', { entidade: 'receitas' })).find(x => x.id === outraId);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'editar', registro: { ...r, valor: '90' } }));
  assert.strictEqual(JSON.stringify(sh.data.slice(0, 2)), snapshot);
  assert.ok(antes.length > 0);
});

teste('dados de demonstração: gerar, bloquear duplicata, remover só eles', () => {
  const antesR = ok(A.chamar('listar', { entidade: 'receitas' })).length;
  const p = ok(A.chamar('gerarDemo', { opId: opId() }));
  assert.ok(p.contas.some(x => x.nome.startsWith('[DEMO]')));
  const d = ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  assert.ok(d.serie.every(s => s.saldo === null || typeof s.saldo === 'number'));
  assert.ok(d.porPessoa.length >= 2);
  falha(A.chamar('gerarDemo', { opId: opId() }), 'JA_EXISTE');
  const rm = ok(A.chamar('removerDemo', { opId: opId() }));
  assert.ok(rm.removidos > 50);
  assert.strictEqual(ok(A.chamar('listar', { entidade: 'receitas' })).length, antesR);
  assert.ok(!rm.contas.some(x => x.nome.startsWith('[DEMO]')));
});

teste('período anual e personalizado; comparativo', () => {
  const a = ok(A.chamar('dashboard', { inicio: '2026-01-01', fim: '2026-12-31' }));
  assert.strictEqual(a.serie.length, 12);
  assert.strictEqual(a.comparativo.anterior.inicio, '2025-01-01');
  const p = ok(A.chamar('dashboard', { inicio: '2026-09-05', fim: '2026-09-14' }));
  assert.strictEqual(p.comparativo.anterior.fim, '2026-09-04');
  falha(A.chamar('dashboard', { inicio: '2026-09-30', fim: '2026-09-01' }), 'VALIDACAO');
});

teste('estranho sem acesso à planilha recebe "negado", não dados', () => {
  A.como('estranho@gmail.com');
  assert.strictEqual(ok(A.chamar('iniciar')).estado, 'negado');
  falha(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  A.como('dono@gmail.com');
});

teste('valores pt-BR lidos da planilha editada à mão', () => {
  const sh = A.ss.getSheetByName('Receitas');
  const col = sh.data[0].indexOf('valor');
  sh.data[1][col] = '1.234,56';
  const l = ok(A.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' }));
  assert.ok(l.cards.receitas.total >= 123456);
});

console.log(`\n${n} testes passaram.`);
