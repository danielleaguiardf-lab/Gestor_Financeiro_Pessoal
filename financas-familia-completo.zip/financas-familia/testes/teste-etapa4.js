// Testes da Etapa 4 (notificações, duplicados, histórico, backup, automação, segurança) com data fixa 05/10/2026.
const assert = require('assert');
const { criarAmbiente } = require('./ambiente');

let op = 0; const opId = () => 'op-etapa4-' + (++op);
let nid = 0; const novoId = () => 'dddddddd-eeee-4fff-8aaa-' + String(++nid).padStart(12, '0');
const ok = r => { if (!r.ok) throw new Error('Esperava ok: ' + JSON.stringify(r.erro)); return r.data; };
const falha = (r, cod, trecho) => {
  assert.strictEqual(r.ok, false, 'esperava falha ' + cod);
  if (cod) assert.strictEqual(r.erro.codigo, cod, JSON.stringify(r.erro));
  if (trecho) assert.ok(r.erro.mensagem.includes(trecho), r.erro.mensagem);
};
let n = 0; const teste = (nome, fn) => { fn(); n++; console.log('✓', nome); };

const A = criarAmbiente({ hoje: '2026-10-05' });
A.ctx.instalar();
const pac = ok(A.chamar('criarFamilia', { opId: opId(), nomeFamilia: 'Família Teste', nomeUsuario: 'Dani', conta: { nome: 'Conta A', tipo: 'corrente', saldo_inicial: '5000', data_saldo_inicial: '2026-09-01' } }));
const contaA = pac.contas[0].id;
const salvar = (ent, reg, extra) => ok(A.chamar('salvar', Object.assign({ opId: opId(), entidade: ent, modo: 'criar', registro: Object.assign({ id: novoId() }, reg) }, extra || {})));
const notifs = () => ok(A.chamar('notificacoes', {}));
const conta = (desc, venc, extra) => salvar('despesas', Object.assign({ descricao: desc, valor: '100', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-01', data_vencimento: venc, status: 'pendente' }, extra || {}));

// ----------------------------------------------------------- Notificações
teste('notificações de vencimento por faixa: atrasada, hoje, amanhã, 3 e 7 dias; distante não aparece', () => {
  conta('Luz', '2026-10-02'); conta('Água', '2026-10-05'); conta('Gás', '2026-10-06'); conta('Internet', '2026-10-08'); conta('Escola', '2026-10-11'); conta('IPTU', '2026-10-30');
  const it = notifs().itens.filter(x => x.tipo === 'vencimentos');
  const por = d => it.find(x => x.titulo.startsWith(d));
  assert.ok(por('Luz').titulo.includes('3 dias de atraso') && por('Luz').nivel === 'perigo');
  assert.ok(por('Água').titulo.includes('vence hoje'));
  assert.ok(por('Gás').titulo.includes('vence amanhã') && por('Gás').nivel === 'alerta');
  assert.ok(por('Internet').chave.endsWith(':3dias'));
  assert.ok(por('Escola').chave.endsWith(':7dias') && por('Escola').nivel === 'info');
  assert.ok(!por('IPTU'));
  assert.strictEqual(notifs().naoLidas, it.length);
});

teste('marcar como lida vale só para quem marcou; a mudança de faixa gera aviso novo', () => {
  const luz = notifs().itens.find(x => x.titulo.startsWith('Luz'));
  const r = ok(A.chamar('marcarNotificacoes', { chaves: [luz.chave] }));
  assert.strictEqual(r.itens.find(x => x.chave === luz.chave).lida, true);
  assert.strictEqual(r.itens[r.itens.length - 1].lida, true, 'lidas vão para o fim da lista');
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'm@x.com', nome: 'Carlos', perfil: 'membro' }));
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'v@x.com', nome: 'Vovó', perfil: 'visualizador' }));
  A.como('m@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  assert.strictEqual(notifs().itens.find(x => x.chave === luz.chave).lida, false);
  A.como('v@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  const rv = ok(A.chamar('marcarNotificacoes', { todas: true }));
  assert.strictEqual(rv.naoLidas, 0, 'visualizador também consegue marcar como lida');
  A.como('dono@gmail.com');
  // Gás passa de "amanhã" para "hoje": nova notificação, mesmo tendo marcado a anterior
  const gas = notifs().itens.find(x => x.titulo.startsWith('Gás'));
  ok(A.chamar('marcarNotificacoes', { chaves: [gas.chave] }));
  A.setHoje('2026-10-06');
  const gas2 = notifs().itens.find(x => x.titulo.startsWith('Gás'));
  assert.ok(gas2.titulo.includes('vence hoje') && gas2.lida === false);
  A.setHoje('2026-10-05');
  ok(A.chamar('marcarNotificacoes', { chaves: [luz.chave], desmarcar: true }));
  assert.strictEqual(notifs().itens.find(x => x.chave === luz.chave).lida, false);
});

teste('preferências: cada pessoa escolhe os tipos de aviso que recebe', () => {
  const r = ok(A.chamar('prefsNotificacoes', { prefs: { vencimentos: false } }));
  assert.strictEqual(r.prefs.vencimentos, false);
  assert.strictEqual(r.prefs.faturas, true);
  assert.ok(!r.itens.some(x => x.tipo === 'vencimentos'));
  A.como('m@x.com');
  assert.ok(notifs().itens.some(x => x.tipo === 'vencimentos'));
  A.como('dono@gmail.com');
  ok(A.chamar('prefsNotificacoes', { prefs: {} }));
  assert.ok(notifs().itens.some(x => x.tipo === 'vencimentos'));
});

teste('pagar a conta faz o aviso sumir', () => {
  const agua = ok(A.chamar('listar', { entidade: 'despesas' })).find(x => x.descricao === 'Água');
  ok(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id: agua.id, valor: '100', data: '2026-10-05' }));
  assert.ok(!notifs().itens.some(x => x.titulo.startsWith('Água')));
});

teste('avisos de fatura, limite do cartão, orçamento, metas, dívidas e receita atrasada', () => {
  const k = novoId();
  salvar('cartoes', { id: k, nome: 'Roxo', limite: '1000', dia_fechamento: '1', dia_vencimento: '8', conta_pagamento_id: contaA });
  ok(A.chamar('salvarCompra', { opId: opId(), compra: { id: novoId(), cartao_id: k, descricao: 'TV', valor_total: '900', parcelas: 1, categoria: 'Moradia', data_compra: '2026-09-20', responsavel: 'Dani' } }));
  salvar('orcamentos', { competencia: '2026-10', categoria: 'Moradia', valor_planejado: '500' });
  salvar('metas', { nome: 'Viagem', valor_desejado: '1000', prazo: '2026-10-20' });
  salvar('metas', { nome: 'Celular', valor_desejado: '100', valor_inicial: '100' });
  salvar('dividas', { nome: 'Empréstimo', valor_original: '1000', saldo_inicial: '1000', qtd_parcelas: '10', valor_parcela_inicial: '100', data_contratacao: '2026-09-01', dia_vencimento: '7' });
  salvar('receitas', { descricao: 'Freela', valor: '300', categoria: 'Renda extra', responsavel: 'Dani', data: '2026-10-01', status: 'prevista' });
  const it = notifs().itens;
  const tem = (tipo, trecho) => it.some(x => x.tipo === tipo && (x.titulo + ' ' + x.texto).includes(trecho));
  assert.ok(tem('faturas', 'Fatura Roxo (out/26) vence em 08/10/2026'), JSON.stringify(it.filter(x => x.tipo === 'faturas')));
  assert.ok(tem('cartoes', '90% do limite'));
  assert.ok(tem('orcamento', 'Orçamento de Moradia estourado'));
  assert.ok(tem('metas', 'Viagem: prazo em 15 dias'));
  assert.ok(tem('metas', 'Meta alcançada: Celular'));
  assert.ok(tem('dividas', 'Empréstimo: parcela 1 vence em 07/10/2026'), JSON.stringify(it.filter(x => x.tipo === 'dividas')));
  assert.ok(tem('recebimentos', 'Freela: previsto para 01/10/2026'));
  assert.ok(it.find(x => x.tipo === 'faturas').acao.cartao_id === k);
});

// -------------------------------------------------------------- Duplicados
teste('possível duplicado: mesmo valor, descrição parecida, datas próximas — ignora parcelas e séries', () => {
  salvar('despesas', { descricao: 'Mercado Extra', valor: '235,40', categoria: 'Alimentação', subcategoria: 'Supermercado', responsavel: 'Dani', data_compra: '2026-10-03', status: 'paga' });
  A.como('m@x.com');
  salvar('despesas', { descricao: 'mercado extra', valor: '235.40', categoria: 'Alimentação', subcategoria: 'Supermercado', responsavel: 'Carlos', data_compra: '2026-10-04', status: 'paga' });
  A.como('dono@gmail.com');
  salvar('despesas', { descricao: 'Mercado Extra', valor: '235.40', categoria: 'Alimentação', responsavel: 'Dani', data_compra: '2026-09-20', status: 'paga' }); // longe demais
  salvar('despesas', { descricao: 'Academia', valor: '99', categoria: 'Pessoal', responsavel: 'Dani', data_compra: '2026-10-01', status: 'paga', recorrencia: 'mensal' });
  salvar('despesas', { descricao: 'Carnê', valor: '300', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-01', status: 'pendente' }, { parcelas: 3 });
  const dups = notifs().itens.filter(x => x.tipo === 'duplicados');
  assert.strictEqual(dups.length, 1, JSON.stringify(dups.map(d => d.titulo)));
  assert.ok(dups[0].texto.includes('lançadas por Dani e Carlos'));
  assert.strictEqual(dups[0].acao.duplicado.registros.length, 2);
  ok(A.chamar('marcarNotificacoes', { chaves: [dups[0].chave] }));
  assert.strictEqual(notifs().itens.find(x => x.tipo === 'duplicados').lida, true);
});

// ------------------------------------------------------------- Histórico
teste('histórico de alterações: só administrador, com filtros, nomes e paginação', () => {
  A.como('m@x.com');
  falha(A.chamar('historico', {}), 'SEM_PERMISSAO');
  A.como('dono@gmail.com');
  const h = ok(A.chamar('historico', {}));
  assert.ok(h.total > 20);
  assert.ok(h.itens[0].data_hora >= h.itens[h.itens.length - 1].data_hora, 'mais recente primeiro');
  const doCarlos = ok(A.chamar('historico', { usuario: 'm@x.com' }));
  assert.ok(doCarlos.itens.length >= 1 && doCarlos.itens.every(x => x.nome === 'Carlos'));
  const pag = ok(A.chamar('historico', { acao: 'pagar' }));
  assert.ok(pag.itens.every(x => x.acao === 'pagar') && pag.itens[0].detalhes.valor === '100.00');
  const metas = ok(A.chamar('historico', { entidade: 'metas' }));
  assert.ok(metas.itens.length === 2);
  assert.ok(h.usuarios['m@x.com'] === 'Carlos');
  assert.strictEqual(ok(A.chamar('historico', { inicio: '2027-01-01' })).total, 0);
  // paginação
  for (let i = 0; i < 40; i++) salvar('despesas', { descricao: 'x' + i, valor: '1', categoria: 'Outros', responsavel: 'Dani', data_compra: '2026-08-01', status: 'paga' });
  const p1 = ok(A.chamar('historico', { pagina: 1 })), p2 = ok(A.chamar('historico', { pagina: 2 }));
  assert.strictEqual(p1.itens.length, 50);
  assert.ok(p1.paginas >= 2 && p2.itens.length > 0 && p2.itens[0].data_hora <= p1.itens[49].data_hora);
});

teste('edição feita à mão na planilha fica registrada no histórico', () => {
  const sh = A.ss.getSheetByName('Despesas');
  A.ctx.onEdit({ range: sh.getRange(3, 4), source: A.ss, value: '999', user: { getEmail: () => 'm@x.com' } });
  A.ctx.onEdit({ range: A.ss.getSheetByName('Histórico de alterações').getRange(2, 1), source: A.ss });
  const h = ok(A.chamar('historico', { acao: 'edicao_manual' }));
  assert.strictEqual(h.total, 1);
  assert.strictEqual(h.itens[0].entidade, 'despesas');
  assert.strictEqual(h.itens[0].nome, 'Carlos');
  assert.strictEqual(h.itens[0].detalhes.aba, 'Despesas');
});

// ------------------------------------------------- Backup e exportação
teste('cópia de segurança copia todas as abas para uma planilha nova e guarda o registro', () => {
  A.como('m@x.com');
  falha(A.chamar('backup', { opId: opId() }), 'SEM_PERMISSAO');
  A.como('dono@gmail.com');
  const r = ok(A.chamar('backup', { opId: opId() }));
  const nova = A.criadas[A.criadas.length - 1];
  assert.strictEqual(nova.sheets.length, 17, 'a aba vazia inicial foi removida');
  assert.deepStrictEqual(nova.sheets.map(s => s.nome).slice(0, 3), ['Usuários', 'Famílias', 'Receitas']);
  assert.strictEqual(JSON.stringify(nova.sheets.find(s => s.nome === 'Despesas').data), JSON.stringify(A.ss.getSheetByName('Despesas').data));
  assert.strictEqual(r.abas.length, 17);
  assert.ok(r.xlsx.endsWith('format=xlsx') && r.abas[2].csv.includes('format=csv&gid='));
  const seg = ok(A.chamar('seguranca', {}));
  assert.strictEqual(seg.backups.length, 1);
  assert.ok(!seg.problemas.some(p => p.codigo === 'sem_backup'));
});

// ------------------------------------------------------------- Automação
teste('automação diária: gera recorrências, registra a execução e faz backup semanal se ativado', () => {
  salvar('receitas', { descricao: 'Salário', valor: '4000', categoria: 'Salário', responsavel: 'Dani', data: '2026-10-05', status: 'recebida', recorrencia: 'mensal' });
  ok(A.chamar('configSistema', { opId: opId(), backup_semanal: true }));
  A.setHoje('2026-11-03');
  const antes = A.criadas.length;
  Object.keys(A.ctx._cache).forEach(k => delete A.ctx._cache[k]);
  const reg = A.ctx.automacaoDiaria();
  assert.strictEqual(reg.erro, '');
  assert.ok(reg.recorrencias >= 1, 'gerou a ocorrência de dezembro');
  assert.ok(reg.backup, 'fez backup (último tinha 29 dias)');
  assert.strictEqual(A.criadas.length, antes + 1);
  Object.keys(A.ctx._cache).forEach(k => delete A.ctx._cache[k]);
  const reg2 = A.ctx.automacaoDiaria();
  assert.strictEqual(reg2.recorrencias, 0, 'não duplica');
  assert.strictEqual(reg2.backup, '', 'backup só uma vez por semana');
  const seg = ok(A.chamar('seguranca', {}));
  assert.strictEqual(seg.automacao.log.length, 2);
  assert.strictEqual(seg.automacao.ativaRecente, true);
  assert.ok(ok(A.chamar('historico', { acao: 'automacao' })).itens[0].nome === 'Automação');
  A.setHoje('2026-10-05');
});

// --------------------------------------------------------- Segurança
teste('revisão de acesso aponta estranhos, revogados com acesso, visualizador editor e membro sem acesso', () => {
  A.compartilhados.editores.add('intruso@gmail.com');
  A.compartilhados.editores.add('v@x.com'); // visualizador com edição
  const membros = ok(A.chamar('iniciar')).membros;
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'ex@x.com', nome: 'Ex', perfil: 'membro' }));
  const ex = ok(A.chamar('iniciar')).membros.find(m => m.email === 'ex@x.com');
  ok(A.chamar('alterarMembro', { opId: opId(), id: ex.id, status: 'revogado' }));
  A.compartilhados.editores.add('ex@x.com'); // alguém recompartilhou à mão
  A.compartilhados.editores.delete('m@x.com'); // membro perdeu o acesso
  const seg = ok(A.chamar('seguranca', {}));
  const cod = c => seg.problemas.find(p => p.codigo === c);
  assert.ok(cod('estranho') && cod('estranho').email === 'intruso@gmail.com');
  assert.ok(cod('revogado') && cod('revogado').email === 'ex@x.com');
  assert.ok(cod('leitor_editor') && cod('leitor_editor').email === 'v@x.com');
  assert.ok(cod('sem_acesso') && cod('sem_acesso').email === 'm@x.com');
  assert.ok(cod('sem_protecao'));
  assert.ok(cod('edicao_manual'));
  assert.ok(seg.acesso.some(a => a.email === 'intruso@gmail.com' && a.status === 'desconhecido'));
  void membros;
  A.como('m@x.com'); falha(A.chamar('seguranca', {}), 'SEM_ACESSO_PLANILHA'); A.como('dono@gmail.com'); // perdeu o acesso no próprio cenário
});

teste('correções de acesso com um toque', () => {
  ok(A.chamar('corrigirAcesso', { opId: opId(), email: 'intruso@gmail.com', acao: 'remover' }));
  ok(A.chamar('corrigirAcesso', { opId: opId(), email: 'ex@x.com', acao: 'remover' }));
  ok(A.chamar('corrigirAcesso', { opId: opId(), email: 'v@x.com', acao: 'leitor' }));
  const r = ok(A.chamar('corrigirAcesso', { opId: opId(), email: 'm@x.com', acao: 'compartilhar' }));
  assert.ok(!A.compartilhados.editores.has('intruso@gmail.com'));
  assert.ok(!A.compartilhados.editores.has('v@x.com') && A.compartilhados.leitores.has('v@x.com'));
  assert.ok(A.compartilhados.editores.has('m@x.com'));
  ['estranho', 'revogado', 'leitor_editor', 'sem_acesso'].forEach(c => assert.ok(!r.problemas.some(p => p.codigo === c), 'continuou ' + c));
  falha(A.chamar('corrigirAcesso', { opId: opId(), email: 'dono@gmail.com', acao: 'remover' }), 'VALIDACAO');
  falha(A.chamar('corrigirAcesso', { opId: opId(), email: 'ninguem@x.com', acao: 'compartilhar' }), 'VALIDACAO');
});

teste('proteger a planilha: abas com aviso e ocultas, aba LEIA-ME, e o app continua gravando', () => {
  const r = ok(A.chamar('proteger', { opId: opId(), ativar: true }));
  assert.strictEqual(r.protegida, true);
  assert.strictEqual(A.ss.getSheets()[0].nome, 'LEIA-ME');
  const desp = A.ss.getSheetByName('Despesas');
  assert.strictEqual(desp.isSheetHidden(), true);
  assert.strictEqual(desp.protecoes.length, 1);
  assert.strictEqual(desp.protecoes[0].isWarningOnly(), true);
  // proteger de novo não duplica
  ok(A.chamar('proteger', { opId: opId(), ativar: true }));
  assert.strictEqual(desp.protecoes.length, 1);
  // o app continua funcionando (inclusive criando família nova não; aqui, gravando lançamento)
  salvar('despesas', { descricao: 'Depois da proteção', valor: '10', categoria: 'Outros', responsavel: 'Dani', data_compra: '2026-10-05', status: 'paga' });
  assert.ok(ok(A.chamar('listar', { entidade: 'despesas' })).some(x => x.descricao === 'Depois da proteção'));
  // a aba LEIA-ME não é apagada pela verificação de estrutura
  A.props.ESTRUTURA = '0';
  ok(A.chamar('iniciar'));
  assert.ok(A.ss.getSheetByName('LEIA-ME'));
  const d = ok(A.chamar('proteger', { opId: opId(), ativar: false }));
  assert.strictEqual(d.protegida, false);
  assert.strictEqual(desp.protecoes.length, 0);
  assert.strictEqual(desp.isSheetHidden(), false);
  assert.ok(!A.ss.getSheetByName('LEIA-ME'));
});

teste('versão do app e nenhuma coluna nova (a atualização não mexe na estrutura)', () => {
  assert.ok(ok(A.chamar('iniciar')).versaoApp.startsWith('4.'));
});

console.log(`\n${n} testes da Etapa 4 passaram.`);
