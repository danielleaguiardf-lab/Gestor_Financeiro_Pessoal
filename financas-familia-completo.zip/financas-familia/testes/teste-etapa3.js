// Testes da Etapa 3 (orçamento, metas, dívidas, relatórios, exportação) com data fixa 05/10/2026.
const assert = require('assert');
const { criarAmbiente } = require('./ambiente');

let op = 0; const opId = () => 'op-etapa3-' + (++op);
let nid = 0; const novoId = () => 'cccccccc-dddd-4eee-8fff-' + String(++nid).padStart(12, '0');
const ok = r => { if (!r.ok) throw new Error('Esperava ok: ' + JSON.stringify(r.erro)); return r.data; };
const falha = (r, cod, trecho) => {
  assert.strictEqual(r.ok, false, 'esperava falha ' + cod);
  if (cod) assert.strictEqual(r.erro.codigo, cod, JSON.stringify(r.erro));
  if (trecho) assert.ok(r.erro.mensagem.includes(trecho), r.erro.mensagem);
};
let n = 0; const teste = (nome, fn) => { fn(); n++; console.log('✓', nome); };

const A = criarAmbiente({ hoje: '2026-10-05' });
A.ctx.instalar();
const pac = ok(A.chamar('criarFamilia', { opId: opId(), nomeFamilia: 'Família Teste', nomeUsuario: 'Dani', conta: { nome: 'Conta A', tipo: 'corrente', saldo_inicial: '5000', data_saldo_inicial: '2026-09-01' } }));
const contaA = pac.contas[0].id;
const salvar = (ent, reg, extra) => ok(A.chamar('salvar', Object.assign({ opId: opId(), entidade: ent, modo: 'criar', registro: Object.assign({ id: novoId() }, reg) }, extra || {})));
const despesa = (desc, valor, cat, sub, data) => salvar('despesas', { descricao: desc, valor, categoria: cat, subcategoria: sub || '', responsavel: 'Dani', data_compra: data || '2026-10-03', status: 'paga', conta_id: contaA });
const plan = () => ok(A.chamar('planejamento', {}));
const listar = ent => ok(A.chamar('listar', { entidade: ent }));

// ------------------------------------------------------------- Orçamento
teste('orçamento: gasto por categoria e subcategoria, percentuais e níveis de alerta', () => {
  salvar('orcamentos', { competencia: '2026-10', categoria: 'Alimentação', valor_planejado: '1.000,00' });
  salvar('orcamentos', { competencia: '2026-10', categoria: 'Alimentação', subcategoria: 'Delivery', valor_planejado: '100' });
  salvar('orcamentos', { competencia: '2026-10', categoria: 'Transporte', valor_planejado: '500' });
  despesa('Mercado', '580', 'Alimentação', 'Supermercado');
  despesa('iFood', '120', 'Alimentação', 'Delivery');
  despesa('Mercado setembro', '999', 'Alimentação', 'Supermercado', '2026-09-20');
  const k = novoId();
  salvar('cartoes', { id: k, nome: 'Roxo', limite: '5000', dia_fechamento: '3', dia_vencimento: '10', conta_pagamento_id: contaA });
  ok(A.chamar('salvarCompra', { opId: opId(), compra: { id: novoId(), cartao_id: k, descricao: 'Feira', valor_total: '100', parcelas: 1, categoria: 'Alimentação', subcategoria: 'Feira', data_compra: '2026-10-04', responsavel: 'Dani' } }));
  const o = ok(A.chamar('orcamento', { competencia: '2026-10' }));
  const ali = o.linhas.find(l => l.categoria === 'Alimentação' && !l.subcategoria);
  assert.strictEqual(ali.gasto, 80000); // 580 + 120 + 100 (cartão) — setembro não entra
  assert.strictEqual(ali.pct, 80);
  assert.strictEqual(ali.nivel, 70);
  const del = o.linhas.find(l => l.subcategoria === 'Delivery');
  assert.strictEqual(del.nivel, 101); // ultrapassado
  assert.strictEqual(del.disponivel, -2000);
  assert.strictEqual(o.totalPlanejado, 150000); // a subcategoria não é somada em dobro
  assert.strictEqual(o.totalGastoOrcado, 80000);
  assert.strictEqual(o.linhas.find(l => l.categoria === 'Transporte').nivel, 0);
});

teste('orçamento: não aceita duplicado; copiar do mês anterior sem sobrescrever', () => {
  falha(A.chamar('salvar', { opId: opId(), entidade: 'orcamentos', modo: 'criar', registro: { id: novoId(), competencia: '2026-10', categoria: 'Transporte', valor_planejado: '10' } }), 'VALIDACAO', 'Já existe');
  salvar('orcamentos', { competencia: '2026-11', categoria: 'Transporte', valor_planejado: '700' });
  const r = ok(A.chamar('copiarOrcamento', { opId: opId(), de: '2026-10', para: '2026-11' }));
  assert.strictEqual(r.copiadas, 2);
  const nov = ok(A.chamar('orcamento', { competencia: '2026-11' }));
  assert.strictEqual(nov.linhas.length, 3);
  assert.strictEqual(nov.linhas.find(l => l.categoria === 'Transporte').planejado, 70000); // manteve o que já existia
  assert.strictEqual(nov.anteriorTemOrcamento, true);
  falha(A.chamar('copiarOrcamento', { opId: opId(), de: '2026-10', para: '2026-11' }), 'VALIDACAO', 'Não há o que copiar');
});

teste('alertas de orçamento aparecem no Início', () => {
  const d = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  const orc = d.insights.filter(i => i.acao === 'orcamento');
  assert.ok(orc.some(i => i.texto.includes('Delivery') && i.texto.includes('ultrapassado')), JSON.stringify(orc));
  assert.ok(orc.some(i => i.texto.includes('Alimentação') && i.texto.includes('80%')));
  assert.ok(orc.some(i => i.texto.includes('dentro do orçamento')));
});

// ------------------------------------------------------------------ Metas
let meta;
teste('meta: progresso, prazo restante e valor mensal necessário', () => {
  meta = novoId();
  salvar('metas', { id: meta, nome: 'Reserva', tipo: 'reserva', valor_desejado: '1000', valor_inicial: '200', prazo: '2026-12-31', prioridade: 'alta' });
  const m = plan().metas.find(x => x.id === meta);
  assert.strictEqual(m.info.acumulado, 20000);
  assert.strictEqual(m.info.restante, 80000);
  assert.strictEqual(m.info.pct, 20);
  assert.strictEqual(m.info.dias, 87);
  assert.strictEqual(m.info.meses, 3);
  assert.strictEqual(m.info.mensal, 26667);
  assert.strictEqual(m.valor_acumulado, '200.00');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'metas', modo: 'criar', registro: { id: novoId(), nome: 'X', valor_desejado: '10', data_inicio: '2026-10-05', prazo: '2026-01-01' } }), 'VALIDACAO', 'prazo');
});

teste('meta: contribuição, retirada (limitada ao guardado), ajuste e meta alcançada', () => {
  ok(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'contribuicao', valor: '300', data: '2026-10-05' }));
  falha(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'retirada', valor: '600', data: '2026-10-05' }), 'VALIDACAO', 'maior');
  ok(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'retirada', valor: '100', data: '2026-10-05' }));
  assert.strictEqual(plan().metas.find(x => x.id === meta).info.acumulado, 40000);
  const r = ok(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'ajuste', valor: '1000', data: '2026-10-05', obs: 'conferi o banco' }));
  assert.strictEqual(r.alcancada, true);
  assert.strictEqual(r.meta.status, 'concluida');
  const d = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.ok(d.insights.some(i => i.acao === 'metas' && i.texto.includes('Meta alcançada: Reserva')));
  const m = plan().metas.find(x => x.id === meta);
  assert.strictEqual(m.historico.length, 3);
  ok(A.chamar('removerMovMeta', { opId: opId(), id: meta, mov_id: m.historico[0].id }));
  const m2 = plan().metas.find(x => x.id === meta);
  assert.strictEqual(m2.status, 'ativa');
  assert.strictEqual(m2.info.acumulado, 40000);
});

teste('meta: aviso de prazo próximo', () => {
  salvar('metas', { nome: 'Presente', valor_desejado: '500', prazo: '2026-10-20' });
  const d = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.ok(d.insights.some(i => i.texto.includes('Prazo da meta Presente termina em 15 dias')));
});

// ---------------------------------------------------------------- Dívidas
let div;
teste('dívida com juros: parcela separa juros e amortização', () => {
  div = novoId();
  salvar('dividas', { id: div, nome: 'Empréstimo', credor: 'Banco', valor_original: '10000', saldo_inicial: '10000', taxa_juros: '1', qtd_parcelas: '12', valor_parcela_inicial: '888,49', parcelas_pagas_inicial: '0', data_contratacao: '2026-09-15', dia_vencimento: '10', conta_id: contaA });
  let x = plan().dividas.find(d => d.id === div);
  assert.strictEqual(x.info.saldo, 1000000);
  assert.strictEqual(x.info.restantes, 12);
  assert.strictEqual(x.info.proximas[0].vencimento, '2026-10-10');
  // juros 1% de 10.000 = 100; amortiza 788,49
  ok(A.chamar('pagarDivida', { opId: opId(), id: div, tipo: 'parcela', valor: '888.49', data: '2026-10-05' }));
  x = plan().dividas.find(d => d.id === div);
  assert.strictEqual(x.info.saldo, 921151);
  assert.strictEqual(x.info.historico[0].juros, 10000);
  assert.strictEqual(x.info.historico[0].amortizacao, 78849);
  assert.strictEqual(x.info.restantes, 11);
  assert.strictEqual(x.info.proximas[0].vencimento, '2026-11-10');
  assert.strictEqual(x.saldo_devedor, '9211.51');
  assert.strictEqual(x.parcelas_pagas, '1');
  // A projeção quita a dívida no prazo combinado
  assert.ok(x.info.projecao.length === 11 && x.info.projecao[10].saldo === 0, JSON.stringify(x.info.projecao.slice(-2)));
});

teste('amortização extra reduzindo o prazo (mantém a parcela)', () => {
  ok(A.chamar('pagarDivida', { opId: opId(), id: div, tipo: 'amortizacao', valor: '2000', data: '2026-10-06', modo: 'prazo' }));
  const x = plan().dividas.find(d => d.id === div);
  assert.strictEqual(x.info.saldo, 721151);
  assert.strictEqual(x.info.parcela, 88849);
  assert.strictEqual(x.info.restantes, 9); // ln(1 − 0,01×7211,51/888,49)… ≈ 8,5 → 9
  assert.ok(x.info.restantes < 11);
});

teste('amortização extra reduzindo a parcela (mantém o prazo)', () => {
  const d2 = novoId();
  salvar('dividas', { id: d2, nome: 'Outro', valor_original: '10000', saldo_inicial: '10000', taxa_juros: '1', qtd_parcelas: '12', valor_parcela_inicial: '888.49', data_contratacao: '2026-09-15', dia_vencimento: '10' });
  ok(A.chamar('pagarDivida', { opId: opId(), id: d2, tipo: 'amortizacao', valor: '5000', data: '2026-10-05', modo: 'parcela' }));
  const x = plan().dividas.find(d => d.id === d2);
  assert.strictEqual(x.info.restantes, 12);
  assert.ok(Math.abs(x.info.parcela - 44424) <= 1, 'parcela recalculada: ' + x.info.parcela);
});

teste('dívida sem juros; não aceita pagar mais que o saldo; quitação', () => {
  const d3 = novoId();
  salvar('dividas', { id: d3, nome: 'Tia Maria', tipo: 'pessoa', valor_original: '1200', saldo_inicial: '1200', taxa_juros: '', qtd_parcelas: '12', valor_parcela_inicial: '100', data_contratacao: '2026-08-01', dia_vencimento: '5' });
  ok(A.chamar('pagarDivida', { opId: opId(), id: d3, tipo: 'parcela', valor: '100', data: '2026-10-05' }));
  ok(A.chamar('pagarDivida', { opId: opId(), id: d3, tipo: 'amortizacao', valor: '300', data: '2026-10-05' }));
  let x = plan().dividas.find(d => d.id === d3);
  assert.strictEqual(x.info.saldo, 80000);
  assert.strictEqual(x.info.restantes, 8);
  falha(A.chamar('pagarDivida', { opId: opId(), id: d3, tipo: 'amortizacao', valor: '900', data: '2026-10-05' }), 'VALIDACAO', 'maior');
  const antes = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' })).cards.dividas.total;
  ok(A.chamar('pagarDivida', { opId: opId(), id: d3, tipo: 'amortizacao', valor: '800', data: '2026-10-05' }));
  x = plan().dividas.find(d => d.id === d3);
  assert.strictEqual(x.status, 'quitada');
  assert.strictEqual(x.info.restantes, 0);
  const depois = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' })).cards.dividas.total;
  assert.strictEqual(antes - depois, 80000);
  falha(A.chamar('pagarDivida', { opId: opId(), id: d3, tipo: 'parcela', valor: '1', data: '2026-10-05' }), 'VALIDACAO', 'quitada');
});

teste('pagar parcela pode lançar a despesa (sai do saldo); desfazer remove a despesa', () => {
  const saldo = () => ok(A.chamar('contas', { inicio: '2026-10-01', fim: '2026-10-31' })).contas.find(k => k.id === contaA).saldo;
  const s0 = saldo();
  const r = ok(A.chamar('pagarDivida', { opId: opId(), id: div, tipo: 'parcela', valor: '888.49', data: '2026-10-05', conta_id: contaA, lancarDespesa: true }));
  assert.strictEqual(saldo(), s0 - 88849);
  const desp = listar('despesas').find(x => x.descricao.startsWith('Empréstimo — parcela 2/'));
  assert.ok(desp && desp.categoria === 'Financeiro' && desp.subcategoria === 'Empréstimos' && desp.status === 'paga');
  const pid = JSON.parse(r.divida.pagamentos).find(p => p.despesa_id === desp.id).id;
  ok(A.chamar('removerPagDivida', { opId: opId(), id: div, pagamento_id: pid }));
  assert.strictEqual(saldo(), s0);
  assert.ok(!listar('despesas').some(x => x.id === desp.id));
  assert.strictEqual(plan().dividas.find(d => d.id === div).info.saldo, 721151);
});

teste('editar os dados do contrato recalcula a dívida', () => {
  const x = listar('dividas').find(d => d.id === div);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'dividas', modo: 'editar', registro: Object.assign({}, x, { saldo_inicial: '11000' }) }));
  // 11.000 → parcela: juros 110,00 e amortiza 778,49 → 10.221,51; amortização extra de 2.000 → 8.221,51
  assert.strictEqual(plan().dividas.find(d => d.id === div).info.saldo, 822151);
});

// -------------------------------------------------------------- Relatórios
const rel = (tipo, extra) => ok(A.chamar('relatorio', Object.assign({ tipo, inicio: '2026-10-01', fim: '2026-10-31' }, extra || {})));
teste('relatório receitas × despesas bate com o Início e compara com outro período', () => {
  salvar('receitas', { descricao: 'Salário', valor: '4000', categoria: 'Salário', responsavel: 'Dani', data: '2026-10-05', status: 'recebida', conta_id: contaA });
  salvar('receitas', { descricao: 'Salário', valor: '3800', categoria: 'Salário', responsavel: 'Dani', data: '2026-09-05', status: 'recebida', conta_id: contaA });
  const d = ok(A.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  const r = rel('rxd', { comparar: true, b_inicio: '2026-09-01', b_fim: '2026-09-30' });
  assert.strictEqual(r.linhas.length, 1);
  assert.strictEqual(r.totais.receitas, d.cards.receitas.total);
  assert.strictEqual(r.totais.despesas, d.cards.despesas.total);
  assert.strictEqual(r.linhas[0].mes_b, 'set/26');
  assert.strictEqual(r.linhas[0].receitas_b, 380000);
  assert.ok(r.colunas.some(c => c.id === 'var'));
  assert.strictEqual(r.grafico.series.length, 4);
});

teste('relatório por categoria com comparação e variação', () => {
  const r = rel('categorias', { comparar: true, b_inicio: '2026-09-01', b_fim: '2026-09-30' });
  const ali = r.linhas.find(l => l.nome === 'Alimentação');
  assert.strictEqual(ali.valor, 80000);
  assert.strictEqual(ali.valor_b, 99900);
  assert.strictEqual(ali.var, Math.round((80000 - 99900) * 1000 / 99900) / 10);
  assert.strictEqual(r.grafico.tipo, 'barh');
  const sem = rel('categorias');
  assert.strictEqual(sem.grafico.tipo, 'doughnut');
  assert.strictEqual(sem.linhas.reduce((s, l) => s + l.pct, 0) > 99.5, true);
});

teste('demais relatórios: pessoas, cartões, faturas, saldo, economias, orçamento, dívidas, metas', () => {
  const p = rel('pessoas'); assert.ok(p.linhas.find(l => l.nome === 'Dani').receitas === 400000);
  const k = rel('cartoes'); assert.strictEqual(k.linhas[0].nome, 'Roxo'); assert.strictEqual(k.linhas[0].valor, 10000);
  assert.strictEqual(rel('faturas').linhas.length, 0); // compra do dia 04 (após o fechamento no dia 03) cai na fatura de novembro
  const f = rel('faturas', { fim: '2026-11-30' }); assert.strictEqual(f.linhas.length, 1); assert.strictEqual(f.linhas[0].vencimento, '2026-11-10');
  const s = rel('saldo', { inicio: '2026-09-01', fim: '2026-12-31' }); assert.strictEqual(s.linhas.length, 2, 'meses futuros não aparecem');
  const e = rel('economias', { inicio: '2026-09-01', fim: '2026-10-31' }); assert.strictEqual(e.linhas[1].acumulada, e.linhas[0].economia + e.linhas[1].economia);
  const o = rel('orcamento'); assert.strictEqual(o.totais.planejado, 150000); assert.strictEqual(o.linhas.find(l => l.nome === 'Alimentação').realizado, 80000);
  const dv = rel('dividas'); assert.ok(dv.linhas.length >= 2); assert.ok(dv.totais.saldo > 0);
  const mt = rel('metas'); assert.ok(mt.linhas.find(l => l.nome === 'Reserva').periodo !== undefined);
  falha(A.chamar('relatorio', { tipo: 'xyz', inicio: '2026-10-01', fim: '2026-10-31' }), 'VALIDACAO');
  falha(A.chamar('relatorio', { tipo: 'rxd', inicio: '2026-10-31', fim: '2026-10-01' }), 'VALIDACAO');
});

teste('filtro por pessoa nos relatórios', () => {
  salvar('despesas', { descricao: 'Barbeiro', valor: '50', categoria: 'Pessoal', responsavel: 'Carlos', data_compra: '2026-10-02', status: 'paga' });
  const r = rel('categorias', { filtros: { responsavel: 'Carlos' } });
  assert.strictEqual(r.totais.valor, 5000);
});

teste('exportar cria uma planilha no Drive com valores numéricos e links xlsx, csv e pdf', () => {
  const r = ok(A.chamar('exportarRelatorio', { tipo: 'categorias', inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.ok(r.xlsx.endsWith('format=xlsx'));
  assert.ok(r.csv.includes('format=csv&gid=' + A.criadas[A.criadas.length - 1].sheet.getSheetId()));
  assert.ok(r.pdf.includes('format=pdf'));
  const sh = A.criadas[A.criadas.length - 1].sheet;
  assert.strictEqual(sh.nome, 'Relatório');
  assert.strictEqual(sh.data[0][0], 'Despesas por categoria');
  assert.deepStrictEqual(sh.data[4].slice(0, 3), ['Categoria', 'Gasto', '% do total']);
  const ali = sh.data.find(l => l[0] === 'Alimentação');
  assert.strictEqual(ali[1], 800); // reais, como número
  assert.strictEqual(sh.data[sh.data.length - 1][0], 'Total');
});

// -------------------------------------------------------------- Permissões
teste('visualizador lê relatórios e planejamento, mas não altera; membro altera', () => {
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'v@x.com', nome: 'Vovó', perfil: 'visualizador' }));
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'm@x.com', nome: 'Carlos', perfil: 'membro' }));
  A.como('v@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  ok(A.chamar('planejamento', {})); ok(A.chamar('orcamento', { competencia: '2026-10' })); ok(A.chamar('relatorio', { tipo: 'metas', inicio: '2026-10-01', fim: '2026-10-31' }));
  falha(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'contribuicao', valor: '1', data: '2026-10-05' }), 'SEM_PERMISSAO');
  falha(A.chamar('pagarDivida', { opId: opId(), id: div, tipo: 'parcela', valor: '1', data: '2026-10-05' }), 'SEM_PERMISSAO');
  falha(A.chamar('copiarOrcamento', { opId: opId(), de: '2026-10', para: '2026-12' }), 'SEM_PERMISSAO');
  A.como('m@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  ok(A.chamar('copiarOrcamento', { opId: opId(), de: '2026-10', para: '2026-12' }));
  ok(A.chamar('movimentarMeta', { opId: opId(), id: meta, tipo: 'contribuicao', valor: '10', data: '2026-10-05' }));
  A.como('dono@gmail.com');
});

teste('nova tentativa da mesma contribuição não conta duas vezes', () => {
  const antes = plan().metas.find(x => x.id === meta).info.acumulado;
  const o = opId();
  ok(A.chamar('movimentarMeta', { opId: o, id: meta, tipo: 'contribuicao', valor: '50', data: '2026-10-05' }));
  ok(A.chamar('movimentarMeta', { opId: o, id: meta, tipo: 'contribuicao', valor: '50', data: '2026-10-05' }));
  assert.strictEqual(plan().metas.find(x => x.id === meta).info.acumulado, antes + 5000);
});

// --------------------------------------------- Atualização e demonstração
teste('planilha da Etapa 2 recebe as colunas novas de metas e dívidas', () => {
  const B = criarAmbiente({ hoje: '2026-10-05' });
  B.ctx.instalar();
  ok(B.chamar('criarFamilia', { opId: 'mig3-000001', nomeFamilia: 'F', nomeUsuario: 'D' }));
  const sh = B.ss.getSheetByName('Dívidas');
  const novas = ['tipo', 'conta_id', 'saldo_inicial', 'parcelas_pagas_inicial', 'valor_parcela_inicial', 'parcelas_restantes', 'pagamentos'];
  novas.map(c => sh.data[0].indexOf(c)).sort((a, b) => b - a).forEach(i => sh.data.forEach(row => row.splice(i, 1)));
  B.props.ESTRUTURA = '2';
  assert.strictEqual(ok(B.chamar('iniciar')).estado, 'pronto');
  novas.forEach(c => assert.ok(sh.data[0].includes(c), 'faltou ' + c));
});

teste('dados de demonstração incluem orçamento, metas e dívida e são removidos por completo', () => {
  const B = criarAmbiente({ hoje: '2026-10-05' });
  B.ctx.instalar();
  ok(B.chamar('criarFamilia', { opId: 'demo3-00001', nomeFamilia: 'F', nomeUsuario: 'D', demo: true }));
  const p = ok(B.chamar('planejamento', {}));
  assert.strictEqual(p.metas.length, 2);
  assert.strictEqual(p.dividas.length, 1);
  assert.ok(p.dividas[0].info.saldo > 0 && p.dividas[0].info.saldo < 2450000);
  assert.ok(ok(B.chamar('orcamento', { competencia: '2026-10' })).linhas.length === 6);
  const d = ok(B.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.ok(d.cards.dividas.total > 0);
  ok(B.chamar('removerDemo', { opId: 'demo3-00002' }));
  ['Orçamentos', 'Metas financeiras', 'Dívidas'].forEach(nome => assert.strictEqual(B.ss.getSheetByName(nome).getLastRow(), 1, 'sobrou em ' + nome));
});

console.log(`\n${n} testes da Etapa 3 passaram.`);
