// Testes da Etapa 2 com planilha simulada e data fixa (05/10/2026).
const assert = require('assert');
const { criarAmbiente } = require('./ambiente');

let op = 0; const opId = () => 'op-etapa2-' + (++op);
let nid = 0; const novoId = () => 'bbbbbbbb-cccc-4ddd-8eee-' + String(++nid).padStart(12, '0');
const ok = r => { if (!r.ok) throw new Error('Esperava ok: ' + JSON.stringify(r.erro)); return r.data; };
const falha = (r, cod, trecho) => {
  assert.strictEqual(r.ok, false, 'esperava falha ' + cod);
  if (cod) assert.strictEqual(r.erro.codigo, cod, JSON.stringify(r.erro));
  if (trecho) assert.ok(r.erro.mensagem.includes(trecho), r.erro.mensagem);
};
let n = 0; const teste = (nome, fn) => { fn(); n++; console.log('✓', nome); };

const A = criarAmbiente({ hoje: '2026-10-05' });
A.ctx.instalar();
const pac = ok(A.chamar('criarFamilia', { opId: opId(), nomeFamilia: 'Família Teste', nomeUsuario: 'Dani', conta: { nome: 'Conta A', tipo: 'corrente', saldo_inicial: '1000', data_saldo_inicial: '2026-09-01' } }));
const contaA = pac.contas[0].id;
const contaB = novoId();
ok(A.chamar('salvar', { opId: opId(), entidade: 'contas_bancarias', modo: 'criar', registro: { id: contaB, nome: 'Conta B', tipo: 'poupanca', saldo_inicial: '0', data_saldo_inicial: '2026-09-01' } }));

const dash = (ini = '2026-10-01', fim = '2026-10-31', filtros) => ok(A.chamar('dashboard', { inicio: ini, fim, filtros }));
const listar = ent => ok(A.chamar('listar', { entidade: ent }));
const cartoes = () => ok(A.chamar('cartoes', {}));
const contas = () => ok(A.chamar('contas', { inicio: '2026-10-01', fim: '2026-10-31' }));
const saldoConta = id => contas().contas.find(k => k.id === id).saldo;

teste('hoje fixo funciona no ambiente', () => {
  assert.strictEqual(ok(A.chamar('iniciar')).hoje, '2026-10-05');
});

// ---------------------------------------------------------------- Cartões
const cartao = novoId();
teste('cadastro de cartão: só administrador, validações', () => {
  falha(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'criar', registro: { id: novoId(), nome: 'X', limite: '100', dia_fechamento: '40', dia_vencimento: '10' } }), 'VALIDACAO', 'fechamento');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'criar', registro: { id: novoId(), nome: 'X', limite: '0', dia_fechamento: '3', dia_vencimento: '10' } }), 'VALIDACAO');
  ok(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'criar', registro: { id: cartao, nome: 'Roxinho', limite: '3.000,00', dia_fechamento: '3', dia_vencimento: '10', conta_pagamento_id: contaA } }));
  assert.strictEqual(ok(A.chamar('iniciar')).cartoes.length, 1);
});

const compra = (dados) => ok(A.chamar('salvarCompra', { opId: opId(), compra: Object.assign({ id: novoId(), cartao_id: cartao, categoria: 'Alimentação', subcategoria: 'Supermercado', responsavel: 'Dani' }, dados) }));

teste('compra antes do fechamento entra na fatura do mês; no dia do fechamento vai para a seguinte', () => {
  assert.strictEqual(compra({ descricao: 'Mercado', valor_total: '200', parcelas: 1, data_compra: '2026-10-02' }).primeiraFatura, '2026-10');
  assert.strictEqual(compra({ descricao: 'Padaria', valor_total: '50', parcelas: 1, data_compra: '2026-10-03' }).primeiraFatura, '2026-11');
});

let compra3x;
teste('compra parcelada distribui parcelas nas faturas seguintes; centavos não se perdem', () => {
  const id = novoId();
  compra3x = id;
  const r = ok(A.chamar('salvarCompra', { opId: opId(), compra: { id, cartao_id: cartao, descricao: 'Tênis', valor_total: '100', parcelas: 3, categoria: 'Pessoal', subcategoria: 'Vestuário', data_compra: '2026-10-05', responsavel: 'Dani' } }));
  assert.strictEqual(r.primeiraFatura, '2026-11');
  const parc = listar('despesas').filter(d => d.compra_id === id).sort((a, b) => a.fatura.localeCompare(b.fatura));
  assert.deepStrictEqual(parc.map(p => p.fatura), ['2026-11', '2026-12', '2027-01']);
  assert.deepStrictEqual(parc.map(p => p.valor), ['33.34', '33.33', '33.33']);
  assert.deepStrictEqual(parc.map(p => p.data_vencimento), ['2026-11-10', '2026-12-10', '2027-01-10']);
  assert.ok(parc.every(p => p.status === 'pendente' && p.forma_pagamento === 'credito'));
  // repetir a mesma compra (mesmo id) não duplica
  const rep = ok(A.chamar('salvarCompra', { opId: opId(), compra: { id, cartao_id: cartao, descricao: 'Tênis', valor_total: '100', parcelas: 3, categoria: 'Pessoal', data_compra: '2026-10-05', responsavel: 'Dani' } }));
  assert.strictEqual(rep.repetido, true);
  assert.strictEqual(listar('despesas').filter(d => d.compra_id === id).length, 3);
});

teste('cartão com vencimento antes do fechamento (fecha 25, vence 5)', () => {
  const k2 = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'criar', registro: { id: k2, nome: 'Verde', limite: '1000', dia_fechamento: '25', dia_vencimento: '5', conta_pagamento_id: contaB } }));
  const r = ok(A.chamar('salvarCompra', { opId: opId(), compra: { id: novoId(), cartao_id: k2, descricao: 'Farmácia', valor_total: '40', parcelas: 1, categoria: 'Saúde', data_compra: '2026-10-10', responsavel: 'Dani' } }));
  assert.strictEqual(r.primeiraFatura, '2026-11');
  const f = cartoes().cartoes.find(k => k.id === k2).faturas[0];
  assert.strictEqual(f.fechamento, '2026-10-25');
  assert.strictEqual(f.vencimento, '2026-11-05');
  assert.strictEqual(f.status, 'aberta');
});

teste('painel do cartão: limite usado, disponível, percentual e faturas', () => {
  const k = cartoes().cartoes.find(x => x.id === cartao);
  assert.strictEqual(k.usado, 20000 + 5000 + 10000);
  assert.strictEqual(k.disponivel, 300000 - 35000);
  assert.strictEqual(k.faturas.find(f => f.competencia === '2026-10').status, 'fechada'); // fechou dia 03, vence dia 10
  assert.strictEqual(k.fatura_a_pagar.competencia, '2026-10');
  assert.strictEqual(k.competencia_atual, '2026-11');
});

teste('compra no cartão conta como despesa uma vez e não mexe no saldo até pagar a fatura', () => {
  const d = dash();
  assert.strictEqual(d.cards.despesas.total, 20000 + 5000 + 3334 + 4000);
  assert.strictEqual(d.cards.saldo.saldo, 100000);
  const pend = d.detalhes.pendentes.find(x => x._tipo === 'fatura' && x.competencia === '2026-10');
  assert.strictEqual(pend._restante, 20000);
});

teste('pagamento parcial da fatura: saldo cai, parcelas continuam em aberto; não aceita pagar a mais', () => {
  falha(A.chamar('pagar', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', valor: '250', data: '2026-10-05' }), 'VALIDACAO', 'maior');
  ok(A.chamar('pagar', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', valor: '120', data: '2026-10-05' }));
  assert.strictEqual(saldoConta(contaA), 100000 - 12000);
  const p = listar('despesas').find(x => x.descricao === 'Mercado');
  assert.strictEqual(p.status, 'pendente');
  assert.strictEqual(dash().cards.despesas.total, 20000 + 5000 + 3334 + 4000); // a despesa não é contada de novo
});

let pagId;
teste('quitar a fatura marca as parcelas como pagas; remover um pagamento reabre', () => {
  ok(A.chamar('pagar', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', valor: '80', data: '2026-10-06' }));
  const p = listar('despesas').find(x => x.descricao === 'Mercado');
  assert.strictEqual(p.status, 'paga');
  assert.strictEqual(p.data_pagamento, '2026-10-06');
  const f = cartoes().cartoes.find(k => k.id === cartao).faturas.find(x => x.competencia === '2026-10');
  assert.strictEqual(f.status, 'paga');
  falha(A.chamar('pagar', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', valor: '1', data: '2026-10-06' }), 'VALIDACAO', 'já está paga');
  pagId = f.pagamentos[1].id;
  ok(A.chamar('removerPagamento', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', pagamento_id: pagId }));
  assert.strictEqual(listar('despesas').find(x => x.descricao === 'Mercado').status, 'pendente');
  ok(A.chamar('pagar', { opId: opId(), entidade: 'faturas', cartao_id: cartao, competencia: '2026-10', valor: '80', data: '2026-10-05' }));
  // saldo hoje: 1000 − 120 − 80
  assert.strictEqual(saldoConta(contaA), 100000 - 20000);
});

teste('parcela de cartão: não exclui sozinha nem muda valor; editar/excluir a compra inteira', () => {
  const parc = listar('despesas').find(x => x.compra_id === compra3x && x.parcela === '2/3');
  falha(A.chamar('excluir', { opId: opId(), entidade: 'despesas', id: parc.id }), 'VALIDACAO', 'compra inteira');
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'editar', registro: Object.assign({}, parc, { valor: '999', observacoes: 'ok' }) }));
  const depois = listar('despesas').find(x => x.id === parc.id);
  assert.strictEqual(depois.valor, '33.33');
  assert.strictEqual(depois.observacoes, 'ok');
  ok(A.chamar('editarCompra', { opId: opId(), compra: { id: compra3x, descricao: 'Tênis corrida', categoria: 'Pessoal', subcategoria: 'Academia', responsavel: 'Dani' } }));
  assert.ok(listar('despesas').filter(x => x.compra_id === compra3x).every(x => x.descricao.startsWith('Tênis corrida (') && x.subcategoria === 'Academia'));
  const antes = cartoes().cartoes.find(k => k.id === cartao).usado;
  ok(A.chamar('excluirCompra', { opId: opId(), id: compra3x }));
  assert.strictEqual(cartoes().cartoes.find(k => k.id === cartao).usado, antes - 10000);
  ok(A.chamar('restaurarCompra', { opId: opId(), id: compra3x }));
  assert.strictEqual(cartoes().cartoes.find(k => k.id === cartao).usado, antes);
});

teste('cartão com compras não pode ser excluído (só desativado); inativo não aceita compra', () => {
  falha(A.chamar('excluir', { opId: opId(), entidade: 'cartoes', id: cartao }), 'VALIDACAO', 'inativo');
  const k = ok(A.chamar('iniciar')).cartoes.find(x => x.id === cartao);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'editar', registro: Object.assign({}, k, { limite: '3000', status: 'inativo' }) }));
  falha(A.chamar('salvarCompra', { opId: opId(), compra: { id: novoId(), cartao_id: cartao, descricao: 'X', valor_total: '10', parcelas: 1, categoria: 'Outros', data_compra: '2026-10-05', responsavel: 'Dani' } }), 'VALIDACAO', 'inativo');
  const k2 = ok(A.chamar('iniciar')).cartoes.find(x => x.id === cartao);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'editar', registro: Object.assign({}, k2, { limite: '3000', status: 'ativo' }) }));
});

teste('alerta de limite do cartão a partir de 70%', () => {
  compra({ descricao: 'Notebook', valor_total: '2000', parcelas: 1, data_compra: '2026-10-05' });
  const ins = dash().insights.find(i => i.acao === 'cartoes');
  assert.ok(ins && ins.texto.includes('Roxinho') && ins.texto.includes('70%'), JSON.stringify(dash().insights));
});

// ------------------------------------------------- Contas a pagar / receber
let conta;
teste('pagamento parcial de conta: saldo cai só o pago; restante continua em aberto', () => {
  conta = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id: conta, descricao: 'Escola', valor: '500', categoria: 'Família', subcategoria: 'Escola', responsavel: 'Dani', data_compra: '2026-10-01', data_vencimento: '2026-10-08', status: 'pendente', conta_id: contaA } }));
  const s0 = saldoConta(contaA);
  falha(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id: conta, valor: '600', data: '2026-10-05' }), 'VALIDACAO', 'maior');
  const r = ok(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id: conta, valor: '200', data: '2026-10-05' }));
  assert.strictEqual(r.registro.status, 'pendente');
  assert.strictEqual(r.registro.valor_pago, '200.00');
  assert.strictEqual(r.restante, 30000);
  assert.strictEqual(saldoConta(contaA), s0 - 20000);
  const ag = ok(A.chamar('agenda', { inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.strictEqual(ag.pagar.find(x => x.id === conta)._restante, 30000);
  const r2 = ok(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id: conta, valor: '300', data: '2026-10-07' }));
  assert.strictEqual(r2.registro.status, 'paga');
  assert.strictEqual(r2.registro.data_pagamento, '2026-10-07');
  // pagamento com data futura só sai do saldo naquele dia
  assert.strictEqual(saldoConta(contaA), s0 - 20000);
  const pid = JSON.parse(r2.registro.pagamentos)[1].id;
  const r3 = ok(A.chamar('removerPagamento', { opId: opId(), entidade: 'despesas', id: conta, pagamento_id: pid }));
  assert.strictEqual(r3.registro.status, 'pendente');
});

teste('editar o valor de uma conta com pagamentos recalcula a situação', () => {
  const r = listar('despesas').find(x => x.id === conta);
  const e = ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'editar', registro: Object.assign({}, r, { valor: '200', status: 'pendente' }) }));
  assert.strictEqual(e.registro.status, 'paga');
});

teste('adiar vencimento', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id, descricao: 'Luz', valor: '150', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-01', data_vencimento: '2026-10-04', status: 'pendente' } }));
  assert.ok(dash().detalhes.vencidas.some(x => x.id === id));
  ok(A.chamar('adiarVencimento', { opId: opId(), id, data: '2026-10-15' }));
  assert.ok(!dash().detalhes.vencidas.some(x => x.id === id));
  assert.strictEqual(listar('despesas').find(x => x.id === id).data_vencimento, '2026-10-15');
});

teste('receita prevista recebida em partes', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { id, descricao: 'Freela', valor: '1000', categoria: 'Renda extra', responsavel: 'Dani', data: '2026-10-20', status: 'prevista', conta_id: contaB } }));
  const r = ok(A.chamar('pagar', { opId: opId(), entidade: 'receitas', id, valor: '400', data: '2026-10-05' }));
  assert.strictEqual(r.registro.status, 'prevista');
  assert.strictEqual(r.registro.valor_recebido, '400.00');
  assert.strictEqual(saldoConta(contaB), 40000);
  const d = dash();
  assert.strictEqual(d.cards.receitas.recebido, 40000);
  assert.strictEqual(d.cards.receitas.previsto, 60000);
  ok(A.chamar('pagar', { opId: opId(), entidade: 'receitas', id, valor: '600', data: '2026-10-05' }));
  assert.strictEqual(listar('receitas').find(x => x.id === id).status, 'recebida');
});

teste('despesa parcelada (carnê) em 3 vezes', () => {
  const id = novoId();
  const r = ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', parcelas: 3, registro: { id, descricao: 'Sofá', valor: '1000', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-31', data_vencimento: '2026-10-31', status: 'pendente' } }));
  assert.strictEqual(r.parcelas, 3);
  const ps = listar('despesas').filter(x => x.grupo_id === id).sort((a, b) => a.data_vencimento.localeCompare(b.data_vencimento));
  assert.deepStrictEqual(ps.map(p => p.valor), ['333.34', '333.33', '333.33']);
  assert.deepStrictEqual(ps.map(p => p.data_vencimento), ['2026-10-31', '2026-11-30', '2026-12-31']);
  falha(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', parcelas: 3, registro: { id: novoId(), descricao: 'X', valor: '90', categoria: 'Outros', responsavel: 'Dani', data_compra: '2026-10-05', recorrencia: 'mensal' } }), 'VALIDACAO', 'recorrente');
});

// ---------------------------------------------------------- Transferências
teste('transferência entre contas: não muda o total da família nem receitas/despesas', () => {
  const antes = dash();
  const sA = saldoConta(contaA), sB = saldoConta(contaB);
  falha(A.chamar('salvar', { opId: opId(), entidade: 'transferencias', modo: 'criar', registro: { id: novoId(), conta_origem_id: contaA, conta_destino_id: contaA, valor: '10', data: '2026-10-05' } }), 'VALIDACAO', 'diferentes');
  const tid = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'transferencias', modo: 'criar', registro: { id: tid, conta_origem_id: contaA, conta_destino_id: contaB, valor: '150', data: '2026-10-05', pessoa_origem: 'Dani', pessoa_destino: 'Carlos', descricao: 'Reserva' } }));
  const depois = dash();
  assert.strictEqual(depois.cards.saldo.saldo, antes.cards.saldo.saldo);
  assert.strictEqual(depois.cards.receitas.total, antes.cards.receitas.total);
  assert.strictEqual(depois.cards.despesas.total, antes.cards.despesas.total);
  assert.strictEqual(saldoConta(contaA), sA - 15000);
  assert.strictEqual(saldoConta(contaB), sB + 15000);
  const fA = dash('2026-10-01', '2026-10-31', { conta_id: contaA });
  assert.strictEqual(fA.cards.saldo.transferencias, -15000);
  const movB = contas().contas.find(k => k.id === contaB).movimentos;
  assert.ok(movB.some(m => m.tipo === 'transf' && m.valor === 15000));
  ok(A.chamar('excluir', { opId: opId(), entidade: 'transferencias', id: tid }));
  assert.strictEqual(saldoConta(contaA), sA);
});

teste('saldo projetado da conta considera contas a pagar, a receber e faturas', () => {
  const k = contas().contas.find(x => x.id === contaA);
  assert.strictEqual(k.previsto.faturas, 0, 'fatura de outubro já paga e a de novembro não vence em outubro');
  const kNov = ok(A.chamar('contas', { inicio: '2026-11-01', fim: '2026-11-30' })).contas.find(x => x.id === contaA);
  assert.ok(kNov.previsto.faturas >= 5000 + 3334 + 200000);
  assert.strictEqual(kNov.projetado, kNov.saldo + kNov.previsto.agendados + kNov.previsto.receber - kNov.previsto.pagar - kNov.previsto.faturas);
});

// ----------------------------------------------------------- Recorrências
let serie;
teste('receita mensal gera a próxima ocorrência (até o fim do mês seguinte) sem duplicar', () => {
  serie = novoId();
  const r = ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'criar', registro: { id: serie, descricao: 'Salário', valor: '3000', categoria: 'Salário', responsavel: 'Dani', data: '2026-10-05', status: 'recebida', recorrencia: 'mensal', conta_id: contaA } }));
  assert.strictEqual(r.gerados, 1);
  const s = () => listar('receitas').filter(x => x.serie_id === serie).map(x => x.data + ':' + x.status).sort();
  assert.deepStrictEqual(s(), ['2026-10-05:recebida', '2026-11-05:prevista']);
  A.props.RECORRENCIA_DIA = '';
  ok(A.chamar('iniciar'));
  assert.strictEqual(s().length, 2);
});

teste('dia 31 mensal respeita meses curtos', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id, descricao: 'Condomínio', valor: '400', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-31', data_vencimento: '2026-10-31', status: 'pendente', recorrencia: 'mensal' } }));
  const ds = listar('despesas').filter(x => x.serie_id === id).map(x => x.data_compra).sort();
  assert.deepStrictEqual(ds, ['2026-10-31', '2026-11-30']);
});

teste('no mês seguinte gera a próxima; ocorrência excluída não volta', () => {
  A.setHoje('2026-11-10');
  A.props.RECORRENCIA_DIA = '';
  ok(A.chamar('iniciar'));
  const datas = () => listar('receitas').filter(x => x.serie_id === serie).map(x => x.data).sort();
  assert.deepStrictEqual(datas(), ['2026-10-05', '2026-11-05', '2026-12-05']);
  const dez = listar('receitas').find(x => x.serie_id === serie && x.data === '2026-12-05');
  ok(A.chamar('excluir', { opId: opId(), entidade: 'receitas', id: dez.id }));
  A.props.RECORRENCIA_DIA = '';
  ok(A.chamar('iniciar'));
  assert.deepStrictEqual(datas(), ['2026-10-05', '2026-11-05']);
  ok(A.chamar('restaurar', { opId: opId(), entidade: 'receitas', id: dez.id }));
});

teste('alterar valor com "aplicar às próximas" atualiza as ocorrências em aberto', () => {
  const nov = listar('receitas').find(x => x.serie_id === serie && x.data === '2026-11-05');
  const r = ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'editar', aplicarProximas: true, registro: Object.assign({}, nov, { valor: '3300' }) }));
  assert.strictEqual(r.atualizadas, 1);
  assert.strictEqual(listar('receitas').find(x => x.serie_id === serie && x.data === '2026-12-05').valor, '3300.00');
  assert.strictEqual(listar('receitas').find(x => x.serie_id === serie && x.data === '2026-10-05').valor, '3000.00');
});

teste('encerrar a recorrência remove as futuras em aberto e para de gerar', () => {
  const nov = listar('receitas').find(x => x.serie_id === serie && x.data === '2026-11-05');
  const r = ok(A.chamar('salvar', { opId: opId(), entidade: 'receitas', modo: 'editar', registro: Object.assign({}, nov, { recorrencia: 'nenhuma' }) }));
  assert.strictEqual(r.encerradas, 1);
  A.setHoje('2027-01-15');
  A.props.RECORRENCIA_DIA = '';
  ok(A.chamar('iniciar'));
  assert.deepStrictEqual(listar('receitas').filter(x => x.serie_id === serie).map(x => x.data).sort(), ['2026-10-05', '2026-11-05']);
  A.setHoje('2026-10-05');
});

teste('trocar a frequência inicia uma nova série a partir daquele lançamento', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id, descricao: 'Academia', valor: '100', categoria: 'Pessoal', responsavel: 'Dani', data_compra: '2026-10-05', status: 'paga', recorrencia: 'mensal' } }));
  const r = listar('despesas').find(x => x.id === id);
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'editar', registro: Object.assign({}, r, { recorrencia: 'quinzenal' }) }));
  const ativos = listar('despesas').filter(x => x.descricao === 'Academia').map(x => x.data_compra).sort();
  assert.deepStrictEqual(ativos, ['2026-10-05', '2026-10-19', '2026-11-02', '2026-11-16', '2026-11-30']);
});

// ------------------------------------------------------------- Permissões
teste('visualizador não paga; membro sem permissão não paga conta dos outros', () => {
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'v@x.com', nome: 'Vovó', perfil: 'visualizador' }));
  ok(A.chamar('convidarMembro', { opId: opId(), email: 'm@x.com', nome: 'Carlos', perfil: 'membro' }));
  const membros = ok(A.chamar('iniciar')).membros;
  ok(A.chamar('alterarMembro', { opId: opId(), id: membros.find(m => m.email === 'm@x.com').id, editar_todos: false }));
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id, descricao: 'Água', valor: '80', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-05', data_vencimento: '2026-10-20', status: 'pendente' } }));
  A.como('v@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  falha(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id, valor: '80', data: '2026-10-05' }), 'SEM_PERMISSAO');
  falha(A.chamar('salvarCompra', { opId: opId(), compra: { id: novoId() } }), 'SEM_PERMISSAO');
  ok(A.chamar('cartoes', {})); ok(A.chamar('agenda', { inicio: '2026-10-01', fim: '2026-10-31' })); ok(A.chamar('contas', { inicio: '2026-10-01', fim: '2026-10-31' }));
  A.como('m@x.com'); ok(A.chamar('aceitarConvite', { opId: opId() }));
  falha(A.chamar('pagar', { opId: opId(), entidade: 'despesas', id, valor: '80', data: '2026-10-05' }), 'SEM_PERMISSAO');
  falha(A.chamar('salvar', { opId: opId(), entidade: 'cartoes', modo: 'criar', registro: { id: novoId(), nome: 'X', limite: '1', dia_fechamento: '1', dia_vencimento: '2' } }), 'SEM_PERMISSAO');
  const t = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'transferencias', modo: 'criar', registro: { id: t, conta_origem_id: contaA, conta_destino_id: contaB, valor: '5', data: '2026-10-05' } }));
  ok(A.chamar('excluir', { opId: opId(), entidade: 'transferencias', id: t }));
  A.como('dono@gmail.com');
});

teste('nova tentativa da mesma operação de pagamento não paga duas vezes', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'despesas', modo: 'criar', registro: { id, descricao: 'Gás', valor: '100', categoria: 'Moradia', responsavel: 'Dani', data_compra: '2026-10-05', status: 'pendente' } }));
  const o = opId();
  ok(A.chamar('pagar', { opId: o, entidade: 'despesas', id, valor: '40', data: '2026-10-05' }));
  ok(A.chamar('pagar', { opId: o, entidade: 'despesas', id, valor: '40', data: '2026-10-05' }));
  assert.strictEqual(listar('despesas').find(x => x.id === id).valor_pago, '40.00');
});

teste('categorias personalizadas: criar, desativar (some do pacote ativo mas fica registrada)', () => {
  const id = novoId();
  ok(A.chamar('salvar', { opId: opId(), entidade: 'categorias', modo: 'criar', registro: { id, tipo: 'despesa', grupo: 'Pets', nome: 'Ração', cor: '#a16207', icone: '🐶' } }));
  let cat = ok(A.chamar('iniciar')).categorias.find(x => x.id === id);
  assert.strictEqual(cat.ativo, '1');
  ok(A.chamar('salvar', { opId: opId(), entidade: 'categorias', modo: 'editar', registro: Object.assign({}, cat, { ativo: false }) }));
  cat = ok(A.chamar('iniciar')).categorias.find(x => x.id === id);
  assert.strictEqual(cat.ativo, '0');
});

teste('o resumo de contas pagas inclui pagamento de fatura e de contas, sem transferências', () => {
  const d = dash();
  assert.ok(d.detalhes.pagas.some(m => m.tipo === 'fatura'));
  assert.ok(d.detalhes.pagas.every(m => m.tipo !== 'transf' && m.valor < 0));
  assert.strictEqual(d.cards.pagas.total, -d.detalhes.pagas.reduce((s, m) => s + m.valor, 0));
});

// -------------------------------------------- Atualização da Etapa 1 → 2
teste('planilha da Etapa 1 recebe as colunas novas sem perder dados', () => {
  const B = criarAmbiente({ hoje: '2026-10-05' });
  B.ctx.instalar();
  ok(B.chamar('criarFamilia', { opId: 'mig-0000001', nomeFamilia: 'F', nomeUsuario: 'D' }));
  ok(B.chamar('salvar', { opId: 'mig-0000002', entidade: 'despesas', modo: 'criar', registro: { id: novoId(), descricao: 'Antiga', valor: '10', categoria: 'Outros', responsavel: 'D', data_compra: '2026-09-01', status: 'paga' } }));
  const sh = B.ss.getSheetByName('Despesas');
  const novas = ['valor_pago', 'pagamentos', 'serie_id', 'auto', 'grupo_id', 'cartao_id', 'compra_id', 'fatura'];
  const idx = novas.map(c => sh.data[0].indexOf(c));
  sh.data.forEach(row => { for (const i of idx.slice().sort((a, b) => b - a)) row.splice(i, 1); });
  B.props.ESTRUTURA = '1';
  const p = ok(B.chamar('iniciar'));
  assert.strictEqual(p.estado, 'pronto');
  novas.forEach(c => assert.ok(sh.data[0].includes(c), 'faltou coluna ' + c));
  const l = ok(B.chamar('listar', { entidade: 'despesas' }));
  assert.strictEqual(l[0].descricao, 'Antiga');
  assert.strictEqual(ok(B.chamar('dashboard', { inicio: '2026-09-01', fim: '2026-09-30' })).cards.despesas.total, 1000);
});

teste('dados de demonstração da Etapa 2 (cartão, faturas, transferência) são criados e removidos por completo', () => {
  const B = criarAmbiente({ hoje: '2026-10-05' });
  B.ctx.instalar();
  ok(B.chamar('criarFamilia', { opId: 'demo-000001', nomeFamilia: 'F', nomeUsuario: 'D', demo: true }));
  const k = ok(B.chamar('cartoes', {})).cartoes;
  assert.strictEqual(k.length, 1);
  assert.ok(k[0].faturas.some(f => f.status === 'paga'));
  assert.ok(k[0].faturas.some(f => f.restante > 0));
  const d = ok(B.chamar('dashboard', { inicio: '2026-10-01', fim: '2026-10-31' }));
  assert.ok(d.cards.saldo.saldo > 0);
  ok(B.chamar('removerDemo', { opId: 'demo-000002' }));
  ['Cartões', 'Compras no cartão', 'Faturas', 'Transferências', 'Receitas', 'Despesas'].forEach(nome => {
    assert.strictEqual(B.ss.getSheetByName(nome).getLastRow(), 1, 'sobrou dado demo em ' + nome);
  });
});

console.log(`\n${n} testes da Etapa 2 passaram.`);
