const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

function criarAmbiente(opcoes) {
  opcoes = opcoes || {};
  const sheets = []; let gidSeq = 100;
  let emailAtual = 'dono@gmail.com';
  const compartilhados = { editores: new Set(), leitores: new Set() };
  function Sheet(nome) {
    this.nome = nome; this.data = []; this.max = 1000; this.frozen = 0; this.oculta = false; this.protecoes = []; this.gid = ++gidSeq;
  }
  Sheet.prototype = {
    getName() { return this.nome; },
    setName(n) { this.nome = n; return this; },
    getSheetId() { return this.gid; },
    isSheetHidden() { return this.oculta; }, hideSheet() { this.oculta = true; return this; }, showSheet() { this.oculta = false; return this; },
    protect() { const sh = this; const p = { desc: '', aviso: false, setDescription(d) { this.desc = d; return this; }, getDescription() { return this.desc; }, setWarningOnly(w) { this.aviso = w; return this; }, isWarningOnly() { return this.aviso; }, remove() { sh.protecoes.splice(sh.protecoes.indexOf(this), 1); } }; sh.protecoes.push(p); return p; },
    getProtections() { return this.protecoes.slice(); },
    copyTo(dest) { const c = new Sheet('Cópia de ' + this.nome); c.data = JSON.parse(JSON.stringify(this.data)); c.oculta = this.oculta; dest.sheets.push(c); return c; },
    autoResizeColumns() { return this; },
    getLastRow() { for (let i = this.data.length - 1; i >= 0; i--) if (this.data[i] && this.data[i].some(v => v !== '' && v != null)) return i + 1; return 0; },
    getLastColumn() { let m = 0; this.data.forEach(r => { if (r) for (let j = r.length - 1; j >= 0; j--) if (r[j] !== '' && r[j] != null) { m = Math.max(m, j + 1); break; } }); return m; },
    getMaxRows() { return this.max; },
    insertRowsAfter(a, n) { this.max += n; },
    setFrozenRows(n) { this.frozen = n; },
    deleteRows(ini, n) { this.data.splice(ini - 1, n); this.max -= n; },
    getRange(r, c, nr = 1, nc = 1) {
      const sh = this;
      if (r + nr - 1 > sh.max) throw new Error('Range fora dos limites');
      const rg = {
        getSheet() { return sh; }, getA1Notation() { return 'A' + r; }, getNumRows() { return nr; },
        getValues() { const out = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) { const v = (sh.data[r - 1 + i] || [])[c - 1 + j]; row.push(v == null ? '' : v); } out.push(row); } return out; },
        setValues(v) { assert.strictEqual(v.length, nr); v.forEach((row, i) => { assert.strictEqual(row.length, nc); sh.data[r - 1 + i] = sh.data[r - 1 + i] || []; row.forEach((x, j) => { sh.data[r - 1 + i][c - 1 + j] = x; }); }); return rg; },
        setValue(x) { sh.data[r - 1] = sh.data[r - 1] || []; sh.data[r - 1][c - 1] = x; return rg; },
        setNumberFormat() { return rg; }, setFontWeight() { return rg; }, setFontSize() { return rg; }, setBackground() { return rg; }, setFontColor() { return rg; }
      };
      return rg;
    }
  };
  const ss = {
    getId: () => 'PLAN1', getUrl: () => 'https://docs.google.com/spreadsheets/d/PLAN1',
    getSheetByName: n => sheets.find(s => s.nome === n) || null,
    getSheets: () => sheets,
    insertSheet(n, idx) { const s = new Sheet(n); sheets.splice(idx == null ? sheets.length : idx, 0, s); return s; },
    deleteSheet(s) { sheets.splice(sheets.indexOf(s), 1); },
    getOwner: () => ({ getEmail: () => 'dono@gmail.com' }),
    getEditors: () => [...compartilhados.editores].map(e => ({ getEmail: () => e })),
    getViewers: () => [...compartilhados.leitores].filter(e => !compartilhados.editores.has(e)).map(e => ({ getEmail: () => e })),
    addEditor(e) { compartilhados.editores.add(e); }, addViewer(e) { compartilhados.leitores.add(e); },
    removeEditor(e) { compartilhados.editores.delete(e); }, removeViewer(e) { compartilhados.leitores.delete(e); }
  };
  sheets.push(new Sheet('Página1'));
  const props = {}; const cache = {}; const criadas = []; const userProps = {};
  let uuidN = 0;
  const RealDate = Date;
  let DataFixa = RealDate;
  if (opcoes.hoje) {
    const fixo = new RealDate(opcoes.hoje + 'T15:00:00Z').getTime();
    DataFixa = class extends RealDate { constructor(...a) { if (a.length) super(...a); else super(fixo); } static now() { return fixo; } };
  }
  const ctx = {
    console, Date: DataFixa,
    SpreadsheetApp: {
      create: nome => {
        const s1 = new Sheet('Página1');
        const n = criadas.length;
        const novo = { nome, sheets: [s1], getId: () => 'NOVA' + n, getUrl: () => 'https://docs.google.com/spreadsheets/d/NOVA' + n + '/edit', getSheets() { return this.sheets; }, sheet: s1,
          deleteSheet(x) { this.sheets.splice(this.sheets.indexOf(x), 1); } };
        criadas.push(novo);
        return novo;
      },
      getActiveSpreadsheet: () => ss,
      ProtectionType: { SHEET: 'SHEET', RANGE: 'RANGE' },
      openById: id => { if (!['dono@gmail.com', ...compartilhados.editores, ...compartilhados.leitores].includes(emailAtual)) throw new Error('sem acesso'); return ss; },
      flush() {}
    },
    PropertiesService: {
      getScriptProperties: () => ({ getProperty: k => props[k] ?? null, setProperty: (k, v) => { props[k] = v; } }),
      getUserProperties: () => { const u = (userProps[emailAtual] = userProps[emailAtual] || {}); return { getProperty: k => u[k] ?? null, setProperty: (k, v) => { if (String(v).length > 9000) throw new Error('grande demais'); u[k] = v; } }; }
    },
    CacheService: { getScriptCache: () => ({ get: k => cache[k] ?? null, put: (k, v) => { cache[k] = v; } }) },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock() {} }) },
    Session: { getActiveUser: () => ({ getEmail: () => emailAtual }) },
    Utilities: {
      getUuid: () => { uuidN++; return '00000000-0000-4000-8000-' + String(uuidN).padStart(12, '0'); },
      formatDate: (d, tz, fmt) => {
        const p = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).formatToParts(d).reduce((o, x) => (o[x.type] = x.value, o), {});
        return fmt === 'yyyy-MM-dd' ? `${p.year}-${p.month}-${p.day}` : `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;
      }
    },
    ScriptApp: { getService: () => ({ getUrl: () => 'https://script.google.com/macros/s/APP/exec' }) },
    HtmlService: {}, Logger: { log() {} }
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(__dirname + '/../Codigo.gs', 'utf8') + '\nthis.api = api; this.instalar = instalar; this._cache = _cache; this.automacaoDiaria = automacaoDiaria; this.onEdit = onEdit;', ctx);
  return {
    ctx, ss, sheets, props, compartilhados, criadas,
    como(e) { emailAtual = e; },
    setHoje(h) { const fixo = new RealDate(h + 'T15:00:00Z').getTime(); ctx.Date = class extends RealDate { constructor(...a) { if (a.length) super(...a); else super(fixo); } static now() { return fixo; } }; },
    chamar(acao, dados) {
      // cada chamada = uma nova execução do Apps Script (cache limpo)
      Object.keys(ctx._cache).forEach(k => delete ctx._cache[k]);
      return JSON.parse(ctx.api(acao, dados));
    }
  };
}

module.exports = { criarAmbiente };
